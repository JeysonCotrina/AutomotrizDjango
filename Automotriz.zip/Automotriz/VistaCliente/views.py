from django.shortcuts import render , redirect
from django.template import loader
from django.http import HttpResponse
from .models import Auto,Registro
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from .forms import ContactoForm
# Create your views here.
def Index(request):
    tarjeta= Auto.objects.all()
    context = {'tarjeta':tarjeta }
    return render(request,'tarjetas.html',context)

def detalle_auto(request,pk):
    detalle = Auto.objects.get(pk = pk)
    context1 = {'detalle':detalle}
    data = {'form': ContactoForm()}
    context = { **context1,**data}
    if request.method == 'POST':
        formulario = ContactoForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            data['mensaje'] = 'Contacto enviado'
        else:
            data['form'] = formulario
    return render (request,'tarjeta_detalle.html',context)

@login_required
def IndexAdmin(request):
    user = request.user
    grupo = user.groups.all()
    context = {'grupo':grupo}
    return render (request,'index_admin.html',context)

def exit(request):
    logout(request)
    return redirect('/')
