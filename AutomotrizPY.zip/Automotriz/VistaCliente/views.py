from django.shortcuts import render , redirect
from django.template import loader
from django.http import HttpResponse
from .models import Auto,Publicacion
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import logout
from .forms import *
# Create your views here.
def Index(request):
    tarjeta= Publicacion.objects.all()
    context = {'tarjeta':tarjeta }
    return render(request,'tarjetas.html',context)

def detalle_auto(request,pk):
    detalle = Publicacion.objects.get(pk = pk)
    context1 = {'detalle':detalle}
    data = {'form':ContactoForm()}
    if request.method == 'POST':
        formulario = ContactoForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            data['mensaje']='conctacto guardado'
        else: 
            data['form'] = formulario
    context = {**context1,**data}
    return render (request,'tarjeta_detalle.html',context)


def publicar_auto(request, id):
    auto = Auto.objects.get(id=id)
    data = {'FormPubli':FormPublicacion()}
    if request.method=='POST':
        formulario = FormPublicacion(data=request.POST)
        formulario = formulario.save(commit=False)
        formulario.id_auto = auto
        formulario.save()
        data['mensaje']='Publicación Exitosa'
    return render (request,'TemplatePublicacion.html',data)


@login_required
def IndexAdmin(request):
    user = request.user
    grupo = user.groups.all()
    context = {'grupo':grupo}
    return render (request,'index_admin.html',context)

def exit(request):
    logout(request)
    return redirect('/')

@permission_required('app.add_auto')
class RegistroAutoViews(HttpResponse):
    def index(request):
        auto = RegistarAuto()
        data ={'FormCar':RegistarAuto()}
        if request.method == 'POST':
            auto = RegistarAuto(request.POST, request.FILES)
            if auto.is_valid():
                auto.save()
                data['mensaje'] = 'AUTOMOVIL GUARDADO EXITOSAMENTE'
        return render(request,'RegistroAuto.html',data)

@permission_required('app.view_auto')
class CRUDauto(HttpResponse):
    def index(request):
        auto = Auto.objects.all()
        context={'autos':auto}
        return render(request,'CRUDauto.html',context)
    

    
        

    
        
