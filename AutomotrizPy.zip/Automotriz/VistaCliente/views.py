from django.shortcuts import render , redirect, get_object_or_404
from .models import *
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import logout
from .forms import *
from django.http import HttpResponse

# Create your views here.
def index(request):
    marca = Marca.objects.all()
    publi=Publicacion.objects.all()
    return render (request,'PublicacionViewCliente.html',{'tarjeta':publi,'marcas':marca})

def BusquedaMarca(request,id):
    try:
        buscar = Marca.objects.get(id=id)
        auto = Auto.objects.get(marca = buscar)
        publica = Publicacion.objects.filter(id_auto = auto)
    except:
        publica = None
    return render(request,'BusquedaMarca.html',{'publica':publica})

def search(request):
    query = request.GET.get('q')

    if query:
        autos = Auto.objects.filter(modelo__icontains=query)
        publicaciones = Publicacion.objects.filter(id_auto__in=autos)

    return render(request, 'Busqueda.html', {'publicaciones': publicaciones, 'query': query})
            
def DetallesPublicaciones(request,id):
    detalle = Publicacion.objects.get(id = id)
    context1 = {'detalle':detalle}
    data = {'form':ContactoForm()}
    if request.method == 'POST':
        formulario = ContactoForm(data=request.POST)
        formulario = formulario.save(commit=False)
        formulario.id_publicación = detalle
        formulario.save()
        data['mensaje']='Contacto Enviado'
    context = {**context1,**data}
    return render (request,'PublicacionDetalle.html',context)

def ViewContacto(request):
    contactos = Contacto.objects.all()
    context={'contactos':contactos}
    return render(request,'ViewContacto.html',context)

@login_required
def ViewAdmin(request):
    user = request.user
    context = {'user':user}
    return render (request,'index_admin.html',context)

def exit(request):
    logout(request)
    return redirect('/')

#!CRUD RESPORTES--------------------------------------------
def ViewReporteCompra(request):
    registro = Auto.objects.all()
    data = {'registro':registro}
    return render(request,"Reporte.html",data)

def ViewReporteVenta(request):
    registro = Venta.objects.all()
    data = {'registroVenta':registro}
    return render(request,"reporteVenta.html",data)

def ReporteCompleto(request):
    compra = Auto.objects.all()
    venta = Venta.objects.all()
    report = []
    for i, x in zip(compra, venta):
        compras= i.valor_inicial
        ventas = x.id_publicación.precio_venta
        modelo = i.modelo
        rut = x.id_cliente.rut
        ganancias = ventas - compras
        report_data = [compras,ventas,ganancias,modelo,rut]
        report.append(report_data)
        data={'report': report}
    return render(request,"ReporteCompleto.html",data)
#!----------------------------------------------------------

#?CRUD Venta-------------------------------------------------
class RealizarVenta(HttpResponse):
    def AddCliente(request):
        data = {'FormCliente':FormCliente()}
        if request.method == 'POST':
            form = FormCliente(request.POST)
            if form.is_valid():
                rut = form.cleaned_data['rut']
                if not Cliente.objects.filter(rut=rut).exists():
                    form.save()
                    data['mensaje'] =' TODO CORRECTO'
                
        return render(request, 'AddCliente.html', data)


    def AddVenta(request,id):
        detalle = Publicacion.objects.get(id = id)
        #data1 = {'detalle':detalle} los detalles de vehiculo que se va a vender
        data = {'form':FormVenta()}
        if request.method == 'POST':
            formulario = FormVenta(data=request.POST)
            if formulario.is_valid():
                formulario = formulario.save(commit=False)
                formulario.id_publicación = detalle
                formulario.save()
                data['mensaje']='Venta realizada exitosamente'
        return render (request,'AddVenta.html',data)
            
#?----------------------------------------------------------

#CRUD autos-------------------------------------------------
def ViewAdminAuto(request): #Ver listados de autos ya registrados
    auto = Auto.objects.all()
    publi = Publicacion.objects.values_list('id_auto_id', flat=True)
    listapubli = []
    for i in publi:
        listapubli.append(i)
        data2={'publi':listapubli}
    data1={'autos':auto}
    data={**data1,**data2}
    return render(request,'CRUDauto.html',data)

def DetalleAuto(request,pk): #ver detalles de los autos ya registrados
    detalle = Auto.objects.get(pk = pk)
    context = {'detalle':detalle}
    return render (request,'auto_detalle.html',context)

def AddAdminAuto(request):
    auto = RegistarAuto()
    data ={'FormCar':RegistarAuto()}
    if request.method == 'POST':
        auto = RegistarAuto(request.POST, request.FILES)
        if auto.is_valid():
            auto.save()
            data['mensaje'] = 'AUTOMOVIL GUARDADO EXITOSAMENTE'
    return render(request,'AddAuto.html',data)

def ChangeAuto(request,id):
    auto = Auto.objects.get(id=id)
    data = {'changeform':RegistarAuto(instance=auto)}
    if request.method == 'POST':
        form = RegistarAuto(data=request.POST,instance=auto)
        if form.is_valid():
            form.save()
            return redirect('automotrizz:AutosRegistrados')
        data['form'] = form
    return render(request,'change.html',data)


def DeleteAuto(request, id): #Eliminar un auto de la base de datos
    auto = Auto.objects.get(id=id)
    if request.method == 'POST': #Confirmación de eliminación
        auto.delete()
        return redirect('automotrizz:AutosRegistrados')
    return render(request, 'confirm_delete.html', {'id': id})
#----------------------------------------------------------------

# CRUD de publicación--------------------------------------------
def ViewPublicacion(reques):
    publ = Publicacion.objects.all()
    vent = Venta.objects.all()
    for i in publ:
        for x in vent:
            if i.id == x.id_publicación:
                i.disponiblidad = 'Vendido'
            else:
                i.disponiblidad = 'Disponible'
    data = {'ViewPubli':publ}
    return render (reques,'ListadoPublicacion.html',data)

def publicar_auto(request, id): 
    auto = Auto.objects.get(id=id)
    publ = Publicacion.objects.all()
    data1 = {'publi':publ}
    data2 = {'FormPubli':FormPublicacion()}
    if request.method=='POST':
        formulario = FormPublicacion(data=request.POST)
        if formulario.is_valid():
            formulario = formulario.save(commit=False)
            formulario.id_auto = auto
            formulario.save()
            data2['mensaje']='Publicación Exitosa'
    data = {**data1,**data2}
    return render (request,'AddPublicacion.html',data)

def ChangePublicacion(request,id):
    publicacion = get_object_or_404(Publicacion,id=id)
    data = {'changeform':FormPublicacion(instance=publicacion)}
    if request.method == 'POST':
        form = FormPublicacion(data=request.POST,instance=publicacion)
        if form.is_valid():
            form.save()
            return redirect('automotrizz:listado_publicacion')
        data['changeform'] = form
    return render(request,'change.html',data)

def DeletePublicacion(request, id): #Eliminar una publicacion
    publi = Publicacion.objects.get(id=id)
    if request.method == 'POST': #Confirmación de eliminación
        publi.delete()
        return redirect('automotrizz:listado_publicacion')
    return render(request, 'confirm_delete.html', {'id': id})
#----------------------------------------------------------------