create database automotrizdb;
use automotrizdb;