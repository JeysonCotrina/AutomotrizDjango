from django import forms
from .models import *

class ContactoForm(forms.ModelForm):
    class Meta:
        model = Contacto
        fields = {'nombre','correo','descripcion'}
        
class RegistarAuto(forms.ModelForm):
    class Meta:
        model = Auto
        fields= '__all__'
        widgets = {'fecha':forms.DateInput(attrs={'type':'date'})}

class FormPublicacion(forms.ModelForm):
    class Meta:
        model = Publicacion
        fields = ['precio_venta']


class FormCliente(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = '__all__'

class FormVenta(forms.ModelForm):
    cliente_form = FormCliente()

    class Meta:
        model = Venta
        fields = ['fecha', 'id_cliente']
        widgets = {'fecha':forms.DateInput(attrs={'type':'date'})}