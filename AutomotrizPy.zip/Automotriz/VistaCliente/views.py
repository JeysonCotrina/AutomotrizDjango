from django.shortcuts import render , redirect, get_object_or_404, reverse
from .models import *
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import logout
from .forms import *
from django.http import HttpResponse
# Create your views here.
from django.db.models import Q
def search(request): #Barra de busqueda
    query = request.GET.get('q')
    if query:
        year = Year.objects.filter(year__icontains=query)
        marca = Marca.objects.filter(nombre__icontains=query)
        autos = Auto.objects.filter(Q(marca__in=marca)| Q(modelo__icontains=query) | Q(year__in=year))
        publicaciones = Publicacion.objects.filter(id_auto__in=autos)
    else:
        publicaciones = None
    return render(request, 'Busqueda.html', {'publicaciones': publicaciones, 'query': query})
            
#!CRUD REPORTES--------------------------------------------
def ViewReporteCompra(request):
    registro = Auto.objects.all()
    data = {'registro':registro}
    return render(request,"Reporte.html",data)

def ViewReporteVenta(request):
    registro = Venta.objects.all()
    data = {'registroVenta':registro}
    return render(request,"reporteVenta.html",data)

def ReporteCompleto(request):
    reporteCompleto = Informe_Compra_Venta.objects.all()
    data = {'Report': []}

    for element in reporteCompleto:
        if element:
            id_venta = element.id_venta.id
            precio_venta = element.id_venta.id_publicación.precio_venta
            precio_compra = element.id_auto.valor_inicial
            ganancias = precio_venta - precio_compra
            modelo = element.id_venta.id_publicación.id_auto.modelo
            rut_cliente = element.id_venta.id_cliente.rut
            data['Report'].append([id_venta, precio_venta, precio_compra, ganancias, modelo, rut_cliente])

    if not data['Report']:
        data['Report'] = None

    return render(request, 'ReporteCompleto.html', data)
#!----------------------------------------------------------

def index(request):
    publi=Publicacion.objects.all()
    return render (request,'PublicacionViewCliente.html',{'tarjeta':publi})




def ViewContacto(request):
    contactos = Contacto.objects.all()
    context={'contactos':contactos}
    return render(request,'ViewContacto.html',context)

@login_required
def ViewAdmin(request):
    user = request.user
    context = {'user':user}
    return render (request,'index_admin.html',context)

def exit(request):
    logout(request)
    return redirect('/')

def ViewAdminAuto(request): #Ver listados de autos ya registrados
    auto = Auto.objects.all()
    img = AutoImage.objects.all()
    publi = Publicacion.objects.values_list('id_auto_id', flat=True)
    listapubli = []
    for i in publi:
        listapubli.append(i)
    data2={'publi':listapubli}
    data1={'autos':auto}
    data3 = {'img':img}
    data={**data1,**data2,**data3}
    return render(request,'CRUDauto.html',data)

def DetalleAuto(request, pk):
    detalle = Auto.objects.get(pk=pk)
    img = AutoImage.objects.filter(auto=detalle)
    context = {'detalle': detalle, 'img': img}
    return render(request, 'auto_detalle.html', context)


def DetallesPublicaciones(request,id):
    detalle = Publicacion.objects.get(id = id)
    context1 = {'detalle':detalle}
    img = AutoImage.objects.filter(auto=detalle.id_auto)
    data2 = {'img':img}
    data = {'form':ContactoForm()}
    if request.method == 'POST':
        formulario = ContactoForm(data=request.POST)
        formulario = formulario.save(commit=False)
        formulario.id_publicación = detalle
        formulario.save()
        data['mensaje']='Contacto Enviado'
    context = {**context1,**data,**data2}
    return render (request,'PublicacionDetalle.html',context)

def AddAdminAuto(request):
    auto = RegistarAuto()
    data ={'FormCar':RegistarAuto()}
    if request.method == 'POST':
        auto = RegistarAuto(request.POST, request.FILES)
        if auto.is_valid():
            auto.save()
            data['mensaje'] = 'Vehiculo guardado exitoso'
    return render(request,'AddAuto.html',data)

def AddImg(request, id):
    auto = Auto.objects.get(id=id)
    data = {'FormImg': FormImg()}
    if request.method == 'POST':
        formimg = FormImg(request.POST, request.FILES)
        if formimg.is_valid():
            formimg_instance = formimg.save(commit=False)
            formimg_instance.auto = auto
            formimg_instance.save()
            data['mensaje'] = 'Imagen guardada exitosamente'
        data['FormImg'] = FormImg()
    return render(request, 'AddImg.html', data)
    
def ChangeAuto(request,id):
    auto = Auto.objects.get(id=id)
    data = {'changeform':RegistarAuto(instance=auto)}
    if request.method == 'POST':
        form = RegistarAuto(data=request.POST,instance=auto)
        if form.is_valid():
            form.save()
            return redirect('automotrizz:AutosRegistrados')
        data['form'] = form
    return render(request,'change.html',data)

def DeleteAuto(request, id): #Eliminar un auto de la base de datos
    auto = Auto.objects.get(id=id)
    if request.method == 'POST': #Confirmación de eliminación
        auto.delete()
        return redirect('automotrizz:AutosRegistrados')
    return render(request, 'confirm_delete.html', {'id': id})
#----------------------------------------------------------------










# CRUD de publicación--------------------------------------------
def ViewPublicacion(reques):
    publ = Publicacion.objects.all()
    vent = Venta.objects.all()
    data = {'ViewPubli':publ}
    return render (reques,'ListadoPublicacion.html',data)

def publicar_auto(request, id): 
    auto = Auto.objects.get(id=id)
    publ = Publicacion.objects.all()
    data1 = {'publi':publ}
    data2 = {'FormPubli':FormPublicacion()}
    if request.method=='POST':
        formulario = FormPublicacion(data=request.POST)
        if formulario.is_valid():
            formulario = formulario.save(commit=False)
            formulario.id_auto = auto
            formulario.save()
            data2['mensaje']='Publicación Exitosa'
    data = {**data1,**data2}
    return render (request,'AddPublicacion.html',data)

def ChangePublicacion(request,id):
    publicacion = get_object_or_404(Publicacion,id=id)
    data = {'changeform':FormPublicacion(instance=publicacion)}
    if request.method == 'POST':
        form = FormPublicacion(data=request.POST,instance=publicacion)
        if form.is_valid():
            form.save()
            return redirect('automotrizz:listado_publicacion')
        data['changeform'] = form
    return render(request,'change.html',data)

def DeletePublicacion(request, id): #Eliminar una publicacion
    publi = Publicacion.objects.get(id=id)
    if request.method == 'POST': #Confirmación de eliminación
        publi.delete()
        return redirect('automotrizz:listado_publicacion')
    return render(request, 'confirm_delete.html', {'id': id})
#----------------------------------------------------------------
#?CRUD Venta-------------------------------------------------
def venta_proceso(request, id_publicacion):
    if request.method == 'POST':
        rut = request.POST.get('rut')
        nombre = request.POST.get('nombre')
        apellido = request.POST.get('apellido')
        fecha = request.POST.get('fecha')
        #Comprobar si existe el cliente y si no agregarlo a la bd
        cliente, created = Cliente.objects.get_or_create(rut=rut, defaults={
            'nombre': nombre,
            'apellido': apellido,
        })

        publicacion = get_object_or_404(Publicacion, id=id_publicacion)
        
        # Crear la venta
        venta = Venta(
            fecha=fecha,
            id_cliente=cliente,
            id_publicación=publicacion
        )
        venta.save()
        
        publicacion.disponiblidad = 'Vendido'
        publicacion.save()

        publicacion_id_auto = publicacion.id_auto #DATOS PARA LLENAR EL FORMULARIO
        venta_id = venta.id #DATOS PARA LLENAR EL FORMULARIO
        formulario = ReportCompleto(data = {
            'id_venta' :venta_id,
            'id_auto' : publicacion_id_auto
        }
        )
        formulario.save()

        return render(request, 'venta_success.html', {'venta': venta})
        
    else:
        # Pre-fill the form with data from the Publicacion model
        publicacion = get_object_or_404(Publicacion, id=id_publicacion)
        initial_data = {'id_publicación': publicacion.id}

        return render(request, 'venta_form.html', {'initial_data': initial_data})
#?----------------------------------------------------------
    

#EN DUDA
def MensajeExito(request):
    return render(request,'mensajeExito.html')