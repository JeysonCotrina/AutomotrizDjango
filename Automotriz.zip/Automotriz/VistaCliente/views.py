from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
from .models import Auto

# Create your views here.
def Index(request):
    tarjeta= Auto.objects.all()
    template = loader.get_template('tarjetas.html')
    context = {'tarjeta':tarjeta }
    return HttpResponse(template.render(context,request))