from django import forms
from .models import *

class ContactoForm(forms.ModelForm):
    class Meta:
        model = Contacto
        fields = {'nombre','correo','descripcion'}

class RegistarAuto(forms.ModelForm):
    class Meta:
        model = Auto
        fields = '__all__'
        widgets = {'fecha':forms.DateInput(attrs={'type':'date'})}

class FormPublicacion(forms.ModelForm):
    class Meta:
        model = Publicacion
        fields = ['precio_venta']

class FormCliente(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = '__all__'

class ReportCompleto(forms.ModelForm):
    class Meta:
        model = Informe_Compra_Venta
        fields = '__all__'

class FormImg(forms.ModelForm):
    class Meta:
        model = AutoImage
        fields = ['imagen']

class FormYear(forms.ModelForm):
    class Meta:
        model = Year
        fields = '__all__'

class FormMarca(forms.ModelForm):
    class Meta:
        model = Marca
        fields = '__all__'

class FormCombustible(forms.ModelForm):
    class Meta:
        model = Combustible
        fields = '__all__'

class FormTransmisión(forms.ModelForm):
    class Meta:
        model = Transmisión
        fields = '__all__'