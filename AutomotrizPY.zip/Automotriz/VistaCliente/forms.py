from django import forms
from .models import Contacto,Auto,Publicacion

class ContactoForm(forms.ModelForm):
    class Meta:
        model = Contacto
        fields = {'nombre','correo','descripcion'}
        
class RegistarAuto(forms.ModelForm):
    class Meta:
        model = Auto
        fields= '__all__'
        widgets = {'fecha':forms.DateInput(attrs={'type':'date'})}

class FormPublicacion(forms.ModelForm):
    class Meta:
        model = Publicacion
        fields = ['titulo', 'precio_venta']