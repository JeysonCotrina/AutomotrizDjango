from django.shortcuts import render , redirect
from django.template import loader
from django.http import HttpResponse
from .models import Auto
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
# Create your views here.
def Index(request):
    tarjeta= Auto.objects.all()
    template = loader.get_template('tarjetas.html')
    context = {'tarjeta':tarjeta }
    return HttpResponse(template.render(context,request))

def detalle_auto(request,pk):
    detalle = Auto.objects.get(pk = pk)
    context = {'detalle':detalle}
    return render (request,'tarjeta_detalle.html',context)

@login_required
def IndexAdmin(request):
    return render(request,'index_admin.html')

def exit(request):
    logout(request)
    return redirect('/')
