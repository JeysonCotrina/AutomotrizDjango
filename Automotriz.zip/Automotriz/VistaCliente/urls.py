from django.urls import path,include
from . import views


app_name = 'automotrizz'

urlpatterns=[
    path('',views.Index,name='home'),
    path('auto/<int:pk>/', views.detalle_auto,name='tarjeta_detalle'),
    path('administrador/', views.IndexAdmin, name='index_admin'),
    path('accounts/', include('django.contrib.auth.urls')),
    path('exit/',views.exit, name='exit')
]