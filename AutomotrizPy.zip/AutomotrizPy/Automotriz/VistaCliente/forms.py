from django import forms
from .models import *

class ContactoForm(forms.ModelForm):
    class Meta:
        model = Contacto
        fields = {'nombre','correo','descripcion'}
        
class RegistarAuto(forms.ModelForm):
    class Meta:
        model = Auto
        fields= '__all__'
        widgets = {'fecha':forms.DateInput(attrs={'type':'date'})}

class FormPublicacion(forms.ModelForm):
    class Meta:
        model = Publicacion
        fields = ['precio_venta']


class FormCliente(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = '__all__'

class FormVenta(forms.ModelForm):
    class Meta:
        model = Venta
        fields = ['fecha']
        widgets = {'fecha':forms.DateInput(attrs={'type':'date'})}

class ReportCompleto(forms.ModelForm):
    class Meta:
        model = Informe_Compra_Venta
        fields = '__all__'