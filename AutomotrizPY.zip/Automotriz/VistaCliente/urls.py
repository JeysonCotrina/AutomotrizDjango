from django.urls import path,include
from . import views


app_name = 'automotrizz'

urlpatterns=[
    path('',views.PublicacionesViewCliente,name='home'),
    path('Auto/<int:pk>/', views.DetallesPublicaciones,name='publicacion_detalle'),
    path('PanelAdmin/', views.ViewAdmin, name='index_admin'),
    path('accounts/', include('django.contrib.auth.urls')),
    path('exit/',views.exit, name='exit'),
    path('AddAuto/',views.AddAdminAuto,name='registrarauto'),
    path('ViewAutos/',views.ViewAdminAuto,name='AutosRegistrados'),
    path('PublicaciónAuto/<int:id>/', views.publicar_auto, name='publicar_auto'),
    path('DeleteAuto/<int:id>/', views.Delete, name='eliminar'),
    path('AutoDetalle/<int:pk>/', views.DetalleAuto,name='auto_detalle'),
    path('ListadoPubli/', views.ViewPublicacion,name='listado_publicacion'),

]