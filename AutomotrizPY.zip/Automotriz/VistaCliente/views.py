from django.shortcuts import render , redirect
from .models import Auto,Publicacion
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import logout
from .forms import *

# Create your views here.
def PublicacionesViewCliente(request):
    tarjeta= Publicacion.objects.all()
    context = {'tarjeta':tarjeta }
    return render(request,'PublicacionViewCliente.html',context)

def DetallesPublicaciones(request,pk):
    detalle = Publicacion.objects.get(pk = pk)
    context1 = {'detalle':detalle}
    data = {'form':ContactoForm()}
    if request.method == 'POST':
        formulario = ContactoForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            data['mensaje']='conctacto guardado'
        else: 
            data['form'] = formulario
    context = {**context1,**data}
    return render (request,'PublicacionDetalle.html',context)

@login_required
def ViewAdmin(request):
    user = request.user
    context = {'user':user}
    return render (request,'index_admin.html',context)

def exit(request):
    logout(request)
    return redirect('/')



# CRUD de publicación--------------------------------------------
def publicar_auto(request, id): # Se crea la publicacion, dando el valor que se mostrará al cliente
    auto = Auto.objects.get(id=id)
    data = {'FormPubli':FormPublicacion()}
    if request.method=='POST':
        formulario = FormPublicacion(data=request.POST)
        formulario = formulario.save(commit=False)
        formulario.id_auto = auto
        formulario.save()
        data['mensaje']='Publicación Exitosa'
    return render (request,'AddPublicacion.html',data)

def ViewPublicacion(reques):
    publ = Publicacion.objects.all()
    data = {'ViewPubli':publ}
    return render (reques,'ListadoPublicacion.html',data)

def Delete(request, id): #Eliminar un auto de la base de datos
    publi = Publicacion.objects.get(id=id)
    if request.method == 'POST': #Confirmación de eliminación
        publi.delete()
        return redirect('automotrizz:listado_publicacion')
    return render(request, 'confirm_delete.html', {'id': id})
#-----------------------------------------------------------------


#CRUD autos-------------------------------------------------
def ViewAdminAuto(request): #Ver listados de autos ya registrados
    auto = Auto.objects.all()
    context={'autos':auto}
    return render(request,'CRUDauto.html',context)

def DetalleAuto(request,pk): #ver detalles de los autos ya registrados
    detalle = Auto.objects.get(pk = pk)
    context = {'detalle':detalle}
    return render (request,'auto_detalle.html',context)

def AddAdminAuto(request): #agregar un auto a la base de datos
    auto = RegistarAuto()
    data ={'FormCar':RegistarAuto()}
    if request.method == 'POST':
        auto = RegistarAuto(request.POST, request.FILES)
        if auto.is_valid():
            auto.save()
            data['mensaje'] = 'AUTOMOVIL GUARDADO EXITOSAMENTE'
    return render(request,'AddAuto.html',data)

def Delete(request, id): #Eliminar un auto de la base de datos
    auto = Auto.objects.get(id=id)
    if request.method == 'POST': #Confirmación de eliminación
        auto.delete()
        return redirect('automotrizz:AutosRegistrados')
    return render(request, 'confirm_delete.html', {'id': id})
#----------------------------------------------------------------