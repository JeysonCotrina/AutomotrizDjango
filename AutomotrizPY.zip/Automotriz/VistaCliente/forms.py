from django import forms
from .models import Contacto,Auto

class ContactoForm(forms.ModelForm):
    class Meta:
        model = Contacto
        fields = {'nombre','correo','descripcion'}
        
class RegistarAuto(forms.ModelForm):
    class Meta:
        model = Auto
        fields= '__all__'
        widgets = {'fecha':forms.DateInput(attrs={'type':'date'})}