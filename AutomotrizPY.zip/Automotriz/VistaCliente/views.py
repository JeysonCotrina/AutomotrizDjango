from django.shortcuts import render , redirect
from django.template import loader
from django.http import HttpResponse
from .models import Auto,Publicacion
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from .forms import *
# Create your views here.
def Index(request):
    tarjeta= Publicacion.objects.all()
    context = {'tarjeta':tarjeta }
    return render(request,'tarjetas.html',context)

def detalle_auto(request,pk):
    detalle = Publicacion.objects.get(pk = pk)
    context1 = {'detalle':detalle}
    data = {'form':ContactoForm()}
    if request.method == 'POST':
        formulario = ContactoForm(data=request.POST)
        if formulario.is_valid() and formulario != None:
            formulario.save()
            data['mensaje']='conctacto guardado'
        else: 
            data['form'] = formulario
    context = {**context1,**data}
    return render (request,'tarjeta_detalle.html',context)

class RegistroAutoViews(HttpResponse):
    def index(request):
        carro = RegistarAuto()
        return render(request,'RegistroAuto.html',{'FormCar':carro})
    
    def procesar_formulario(request):
        carro = RegistarAuto(request.POST, request.FILES)
        if carro.is_valid():
            carro.save()
            carro = RegistarAuto()
        return render(request,'RegistroAuto.html',{'FormCar':carro})
    
@login_required
def IndexAdmin(request):
    user = request.user
    grupo = user.groups.all()
    context = {'grupo':grupo}
    return render (request,'index_admin.html',context)

def exit(request):
    logout(request)
    return redirect('/')



