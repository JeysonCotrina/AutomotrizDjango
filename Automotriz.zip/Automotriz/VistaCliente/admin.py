from django.contrib import admin
from .models import Marca,Year,Auto,Registro,Publicacion,Cliente,Venta,Informe_Compra_Venta,Contacto
# Register your models here.


admin.site.register(Marca)
admin.site.register(Year)
admin.site.register(Auto)
admin.site.register(Registro)
admin.site.register(Publicacion)
admin.site.register(Cliente)
admin.site.register(Venta)
admin.site.register(Informe_Compra_Venta)
admin.site.register(Contacto)